import java.awt.event.*;
import javax.swing.*;

public class SumTotalJFrame {
    SumTotalJFrame(){
        JFrame f = new JFrame("Address");
        
        JLabel lblFirstnum = new JLabel("First Number : ");
        lblFirstnum.setBounds(10,10,150,20);
        f.add(lblFirstnum);
        
        JLabel lblSecondnum = new JLabel("Second Number : ");
        lblSecondnum.setBounds(10,50,150,20);
        f.add(lblSecondnum);
        
        JTextField txtFirstNumber = new JTextField("");
        txtFirstNumber.setBounds(150,10,150,20);
        f.add(txtFirstNumber);
        
        JTextField txtSecondNumber = new JTextField("");
        txtSecondNumber.setBounds(150,50,150,20);
        f.add(txtSecondNumber);
        
        
        JLabel resultLabel = new JLabel("Result ");
        resultLabel.setBounds(20,100,150,20);
        f.add(resultLabel);
        
        JTextField Field_result = new JTextField("");
        Field_result.setBounds(150,100,150,20);
        f.add(Field_result);
        
        
        JButton button_sum =new JButton("SUM");
        button_sum.setBounds(20,150,80,20);
        f.add(button_sum);
        JButton button_cancel =new JButton("Cancle");
        button_cancel.setBounds(140,150,80,20);
        f.add(button_cancel);
        
        f.setSize(400,500);;
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        button_sum.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                int a = Integer.parseInt(txtFirstNumber.getText());
                int b = Integer.parseInt(txtSecondNumber.getText());
                int c=a+b;
                System.out.print(c);
                Field_result.setText(""+c);
            }
        }              
        );
        button_cancel.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                txtFirstNumber.setText("");
                txtSecondNumber.setText("");    
                Field_result.setText("");    
            }
        }              
        );
    }
    public static void main(String[] args){
        SumTotalJFrame n = new SumTotalJFrame();
    }
    
}
