import javax.swing.*;
import javax.swing.JCheckBox;
import java.net.*;
        
public class Frame1_ {
    public static void main(String s[]) throws UnknownHostException {  
        
    JFrame f= new JFrame("TextField Example");  
    
    JLabel label=new JLabel("Name : ");
    label.setBounds(10,20, 60,30);
    f.add(label);
    
    JTextField t1; 
    t1=new JTextField("");  
    t1.setBounds(100,20, 100,30);  
    f.add(t1);
    
    JLabel label_address=new JLabel("Address : ");
    label_address.setBounds(10,60, 60,30);
    f.add(label_address);
    
    JTextField t2=new JTextField("");  
    t2.setBounds(100,60, 100,30);  
    f.add(t2);
    
    JLabel label_program = new JLabel("Program");
    label_program.setBounds(10,125,60,30);
    f.add(label_program);
    
    JRadioButton Jbutton_BCA = new JRadioButton("BCA");
    Jbutton_BCA.setBounds(100,125,60,30);
    f.add(Jbutton_BCA);
    
    JRadioButton Jbutton_CSIT = new JRadioButton("CSIT");
    Jbutton_CSIT.setBounds(160,125,60,30);
    f.add(Jbutton_CSIT);
    
    JRadioButton Jbutton_BBA = new JRadioButton("BBA");
    Jbutton_BBA.setBounds(220,125,60,30);
    f.add(Jbutton_BBA);
    
    JLabel Label_yes_or_no = new JLabel("Do you like JAVA");
    
    
    JLabel combo_box_label =new JLabel("Semester ");
   
    String p[]= {"First","Second","Third","Fourth"};
    JComboBox combo_box = new JComboBox(p);
    label_address.setBounds(10,200,150,30);
    combo_box.setBounds(120,200,60,30);
    
    Label_yes_or_no.setBounds(10,160,150,30);
    f.add(Label_yes_or_no);
    
    JCheckBox yes   = new JCheckBox("Yes", true);
    JCheckBox no    = new JCheckBox("No");
    JCheckBox MayBe = new JCheckBox("Maybe");

    
    ButtonGroup bgroup = new ButtonGroup();
    bgroup.add(yes);
    bgroup.add(no);
    bgroup.add(MayBe);
    yes.setBounds(160,160, 60,30);
    no.setBounds(220,160, 60,30);
    MayBe.setBounds(280,160, 100,30);
    f.add(yes);
    f.add(no);
    f.add(MayBe);
    
    f.add(combo_box);
    
    f.setSize(600,600);  
    f.setLayout(null);  
    f.setVisible(true);           
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

//      try{
//            InetAddress address = InetAddress.getByName("www.oreilly.com"); 
//            System.out.println(address);
//        }catch (UnknownHostException ex){
//            System.out.println("Could not findwww.oreilly.com");
//        }
//        try {
//        
//        InetAddress[] addresses = InetAddress.getAllByName("www.oreilly.com"); 
//        for (InetAddress address : addresses) {
//        
//        System.out.println(address);
//        }
//        InetAddress my_address = InetAddress.getLocalHost();
//        System.out.println("This is my IP : "+my_address);
//        }catch (UnknownHostException ex) { 
//            System.out.println("Could not find www.oreilly.com");
//        }

//        InetAddress ia = InetAddress.getByName("www.oreilly.com");
//        System.out.println("This is IP : "+getVersion(ia));
//        
//    }
//     public static int getVersion(InetAddress ia){
//         byte[] address = ia.getAddress();
//         if (address.length == 4) return 4;
//         else if (address.length == 16) return 6;
//         else return -1;
//     }
   
}
